#define TINY_GSM_MODEM_SEQUANS_MONARCH
#define TINY_GSM_RX_BUFFER 1024
#define TINY_GSM_DEBUG Serial

#define BLYNK_TEMPLATE_ID   "MyTemplateID"
#define BLYNK_TEMPLATE_NAME "MyTemplate"
#define BLYNK_AUTH_TOKEN    "LcIEIHmUOMbwC8xi-3Au3CQM7lNajKR9"
#define BLYNK_PRINT         Serial

// =========================================================
// Debug / behavior options
// =========================================================
#define CAN_RX_LOGGING         0
#define NET_DEBUG_LOGGING      1
#define STATUS_INTERVAL_MS     5000UL   // 15 minutes was  900000UL 
#define NET_CHECK_INTERVAL_MS  10000UL
#define RI_ACTIVITY_TIMEOUT_MS 70000UL

#include <Arduino.h>
#include <Wire.h>
#include "driver/twai.h"
#include <ArduinoJson.h>
#include <TinyGsmClient.h>
#include <BlynkSimpleTinyGSM.h>
#include <WiFi.h>

/* =========================================================
   SGW starter kit / PCAL6408A I2C expander
   ========================================================= */
#define I2C_SDA_PIN  8
#define I2C_SCL_PIN  7
#define PCAL_ADDR    0x21

#define REG_INPUT    0x00
#define REG_OUTPUT   0x01
#define REG_CONFIG   0x03

#define IO_P0 (1 << 0)
#define IO_P1 (1 << 1)
#define IO_P2 (1 << 2)
#define IO_P3 (1 << 3)
#define IO_P4 (1 << 4)
#define IO_P5 (1 << 5)
#define IO_P6 (1 << 6)
#define IO_P7 (1 << 7)

uint8_t ioexpOut = 0;

/* =========================================================
   LTE UART
   ========================================================= */
#define LTE_TX_PIN    47
#define LTE_RX_PIN    48
#define LTE_RTS_PIN   33
#define LTE_CTS_PIN   6

/* =========================================================
   TH8056 / CAN
   ========================================================= */
#define TH8056_MODE0_PIN GPIO_NUM_13
#define TH8056_MODE1_PIN GPIO_NUM_14
#define CAN_TX_PIN       GPIO_NUM_17
#define CAN_RX_PIN       GPIO_NUM_18

#define SerialMon Serial

/* =========================================================
   Powertrain decode
   ========================================================= */
#define ENGINE_INFO_1_ID 0x102CA040UL
#define ENGINE_RUNNING_RPM_THRESHOLD 500

/* =========================================================
   Blynk virtual pins
   =========================================================
   V24 = engine running flag
   V25 = engine RPM
   V26 = error/status text
   ========================================================= */

/* =========================================================
   Engine monitor timing
   ========================================================= */
const unsigned long ENGINE_MONITOR_WINDOW_MS = 20UL * 60UL * 1000UL; // 20 min
const unsigned long ENGINE_DEBUG_INTERVAL_MS = 5000UL;               // slower prints
const int ENGINE_RPM_PUBLISH_DELTA = 25;                             // push realistic RPM changes quickly
const uint8_t RPM_AVG_WINDOW = 6;

/* =========================================================
   Cellular config
   ========================================================= */
const char apn[]      = "data.apn.name";
const char gprsUser[] = "";
const char gprsPass[] = "";

/* =========================================================
   Objects
   ========================================================= */
HardwareSerial MODEM_SERIAL(1);
TinyGsm modem(MODEM_SERIAL);
BlynkTimer timer;

/* =========================================================
   App / command state
   ========================================================= */
enum PendingCommand {
  CMD_NONE,
  CMD_UNLOCK_DOOR,
  CMD_LOCK_DOOR,
  CMD_ALARM_ON,
  CMD_ALARM_OFF,
  CMD_LIGHTS_ON,
  CMD_LIGHTS_OFF,
  CMD_REMOTE_START,
  CMD_REMOTE_START_OFF,
  CMD_GET_LOCATION
};

PendingCommand pendingCommand = CMD_NONE;

bool requestVehicleLocation = false;
bool doorUnlocked = false;
bool alarmOn = false;
bool lightsFlashing = false;
bool remoteStarted = false;

/* =========================================================
   Engine state derived from 0x102CA040
   ========================================================= */
uint16_t engineRpmRaw = 0;
int engineRpm = 0;
int engineRpmAvg = 0;
bool engineRunning = false;

int rpmSamples[RPM_AVG_WINDOW] = {0};
uint8_t rpmSampleIndex = 0;
uint8_t rpmSampleCount = 0;

unsigned long engineMonitorUntilMs = 0;
unsigned long lastEngineDebugMs = 0;

bool pendingEnginePush = true;
bool pendingEngineFlagPush = true;
bool pendingEngineErrorPush = true;
bool pendingEngineRpmPush = true;

String errorMessage = "Ready";
String lastPrintedErrorMessage = "";
int lastPrintedEngineRpm = -1;
bool lastPrintedEngineRunning = false;

/* =========================================================
   Bus / network state
   ========================================================= */
unsigned long lastHeartbeat = 0;
unsigned long lastAppActivity = 0;
unsigned long lastNetCheck = 0;
unsigned long lastRingPoll = 0;
unsigned long lastRIActivityMs = 0;
unsigned long bootTime = 0;

const unsigned long HEARTBEAT_INTERVAL = 1200;
const unsigned long BUS_IDLE_TIMEOUT   = 30000;

bool isBusRequestedToWakeUp = false;
bool busIsAlive = false;
bool lastRingState = true;
bool riLossAnnounced = false;

int lastSignalQuality = -1;
uint8_t networkFailCount = 0;
String serialInput;

/* =========================================================
   Blynk outbound cache to reduce messages
   ========================================================= */
bool forceFullBlynkPublish = true;
bool pendingStatePush = true;

long cacheV10 = -999999;
int  cacheV11 = -9999;
int  cacheV12 = -9999;
int  cacheV13 = -9999;
int  cacheV14 = -9999;
int  cacheV20 = -9999;
int  cacheV21 = -9999;
int  cacheV22 = -9999;
int  cacheV23 = -9999;
int  cacheV24 = -9999;
int  cacheV25 = -9999;
String cacheV26 = "";

/* =========================================================
   I2C helpers
   ========================================================= */
void writeReg(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(PCAL_ADDR);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

uint8_t readReg(uint8_t reg) {
  Wire.beginTransmission(PCAL_ADDR);
  Wire.write(reg);
  Wire.endTransmission(false);
  Wire.requestFrom(PCAL_ADDR, (uint8_t)1);

  if (Wire.available()) return Wire.read();
  return 0;
}

void ioexpWrite(uint8_t mask, bool level) {
  if (level) ioexpOut |= mask;
  else       ioexpOut &= ~mask;
  writeReg(REG_OUTPUT, ioexpOut);
}

bool readLteRing() {
  return (readReg(REG_INPUT) & IO_P7) != 0;
}

/* =========================================================
   TH8056 helpers
   ========================================================= */
void th8056SetNormalMode() {
  digitalWrite(TH8056_MODE0_PIN, HIGH);
  digitalWrite(TH8056_MODE1_PIN, HIGH);
}

void th8056SetWakeMode() {
  digitalWrite(TH8056_MODE0_PIN, LOW);
  digitalWrite(TH8056_MODE1_PIN, HIGH);
}

void th8056SetSleepMode() {
  digitalWrite(TH8056_MODE0_PIN, LOW);
  digitalWrite(TH8056_MODE1_PIN, LOW);
}

/* =========================================================
   TWAI timing
   ========================================================= */
static const twai_timing_config_t TWAI_TIMING_33K3 = {
  .brp = 120,
  .tseg_1 = 15,
  .tseg_2 = 4,
  .sjw = 3,
  .triple_sampling = false
};

/* =========================================================
   Helpers
   ========================================================= */
bool engineMonitoringActive() {
  return millis() < engineMonitorUntilMs;
}

void startEngineMonitorWindow() {
  engineMonitorUntilMs = millis() + ENGINE_MONITOR_WINDOW_MS;
  pendingEnginePush = true;
  pendingEngineFlagPush = true;
  pendingEngineErrorPush = true;
  pendingEngineRpmPush = true;
}

void setErrorMessage(const String &msg) {
  if (errorMessage != msg) {
    errorMessage = msg;
    pendingEnginePush = true;
    pendingEngineErrorPush = true;

    if (msg != lastPrintedErrorMessage) {
      SerialMon.print("[ENGINE] STATUS: ");
      SerialMon.println(msg);
      lastPrintedErrorMessage = msg;
    }
  }
}

void addRpmSample(int rpm) {
  rpmSamples[rpmSampleIndex] = rpm;
  rpmSampleIndex = (rpmSampleIndex + 1) % RPM_AVG_WINDOW;
  if (rpmSampleCount < RPM_AVG_WINDOW) rpmSampleCount++;

  long sum = 0;
  for (uint8_t i = 0; i < rpmSampleCount; i++) sum += rpmSamples[i];
  int newAvg = (rpmSampleCount > 0) ? (int)(sum / rpmSampleCount) : rpm;

  if (abs(newAvg - engineRpmAvg) >= ENGINE_RPM_PUBLISH_DELTA || newAvg == 0 || engineRpmAvg == 0) {
    engineRpmAvg = newAvg;
    pendingEnginePush = true;
    pendingEngineRpmPush = true;
  } else {
    engineRpmAvg = newAvg;
  }
}

/* =========================================================
   AT helpers
   ========================================================= */
bool waitForCTS(unsigned long timeoutMs = 8000) {
  unsigned long start = millis();
  while (digitalRead(LTE_CTS_PIN) == HIGH) {
    if (millis() - start >= timeoutMs) return false;
    delay(1);
  }
  return true;
}

String modemReadResponse(unsigned long waitMs) {
  String resp;
  unsigned long start = millis();

  while (millis() - start < waitMs) {
    while (MODEM_SERIAL.available()) {
      char c = (char)MODEM_SERIAL.read();
      resp += c;
      start = millis();
    }
  }
  return resp;
}

String modemSendATGetResp(const char *cmd, unsigned long waitMs = 1500, bool echoToSerial = true) {
  if (!waitForCTS()) {
    SerialMon.println("WARN: CTS stayed HIGH, sending anyway");
  }

  while (MODEM_SERIAL.available()) MODEM_SERIAL.read();

  if (echoToSerial) {
    SerialMon.print("\nTX -> ");
    SerialMon.println(cmd);
  }

  MODEM_SERIAL.print(cmd);
  MODEM_SERIAL.print("\r\n");

  String resp = modemReadResponse(waitMs);

  if (echoToSerial && resp.length()) {
    SerialMon.print(resp);
    SerialMon.println("----");
  }

  return resp;
}

bool respHasOK(const String &resp) {
  return resp.indexOf("\r\nOK") >= 0 ||
         resp.endsWith("OK\r\n") ||
         resp.indexOf("\nOK\n") >= 0;
}

/* =========================================================
   Blynk cached write helpers
   ========================================================= */
void vwIfChangedLong(uint8_t pin, long value, long &cacheRef, bool force = false) {
  if (!Blynk.connected()) return;
  if (force || cacheRef != value) {
    Blynk.virtualWrite(pin, value);
    cacheRef = value;
  }
}

void vwIfChangedInt(uint8_t pin, int value, int &cacheRef, bool force = false) {
  if (!Blynk.connected()) return;
  if (force || cacheRef != value) {
    Blynk.virtualWrite(pin, value);
    cacheRef = value;
  }
}

void vwIfChangedString(uint8_t pin, const String &value, String &cacheRef, bool force = false) {
  if (!Blynk.connected()) return;
  if (force || cacheRef != value) {
    Blynk.virtualWrite(pin, value);
    cacheRef = value;
  }
}

void pushStateNow(bool force = false) {
  if (!Blynk.connected()) return;

  vwIfChangedInt(V20, doorUnlocked ? 1 : 0, cacheV20, force);
  vwIfChangedInt(V21, alarmOn ? 1 : 0, cacheV21, force);
  vwIfChangedInt(V22, lightsFlashing ? 1 : 0, cacheV22, force);
  vwIfChangedInt(V23, remoteStarted ? 1 : 0, cacheV23, force);

  if (force || pendingEngineFlagPush) {
    vwIfChangedInt(V24, engineRunning ? 1 : 0, cacheV24, force);
    pendingEngineFlagPush = false;
  }
  if (force || pendingEngineRpmPush) {
    vwIfChangedInt(V25, engineRpmAvg, cacheV25, force);
    pendingEngineRpmPush = false;
  }
  if (force || pendingEngineErrorPush) {
    vwIfChangedString(V26, errorMessage, cacheV26, force);
    pendingEngineErrorPush = false;
  }

  pendingStatePush = false;
  pendingEnginePush = false;
}

void pushSlowStatus(bool force = false) {
  if (!Blynk.connected()) return;

  int sig = modem.getSignalQuality();
  if (sig >= 0) lastSignalQuality = sig;

  vwIfChangedLong(V10, millis() / 1000UL, cacheV10, true);
  vwIfChangedInt(V11, lastSignalQuality, cacheV11, force);
  vwIfChangedInt(V12, busIsAlive ? 1 : 0, cacheV12, force);
  vwIfChangedInt(V13, modem.isNetworkConnected() ? 1 : 0, cacheV13, force);
  vwIfChangedInt(V14, modem.isGprsConnected() ? 1 : 0, cacheV14, force);
}

/* =========================================================
   CAN helpers
   ========================================================= */
void printCanMessage(const twai_message_t &msg) {
  SerialMon.print("[CAN RX] ");
  SerialMon.print(msg.extd ? "EXT " : "STD ");
  SerialMon.print("ID=0x");
  SerialMon.print(msg.identifier, HEX);
  SerialMon.print(" DLC=");
  SerialMon.print(msg.data_length_code);

  if (!msg.rtr) {
    SerialMon.print(" DATA:");
    for (int i = 0; i < msg.data_length_code; i++) {
      SerialMon.print(' ');
      if (msg.data[i] < 0x10) SerialMon.print('0');
      SerialMon.print(msg.data[i], HEX);
    }
  } else {
    SerialMon.print(" RTR");
  }
  SerialMon.println();
}

void decodeEngineInfo1(const twai_message_t &msg) {
  if (!msg.extd) return;
  if (msg.identifier != ENGINE_INFO_1_ID) return;
  if (msg.data_length_code < 4) return;

  uint16_t raw = ((uint16_t)msg.data[2] << 8) | msg.data[3];
  int rpm = raw / 4;
  bool running = rpm > ENGINE_RUNNING_RPM_THRESHOLD;

  engineRpmRaw = raw;
  engineRpm = rpm;

  addRpmSample(rpm);

  if (engineRunning != running) {
    engineRunning = running;
    pendingEnginePush = true;
    pendingEngineFlagPush = true;

    if (engineRunning) {
      setErrorMessage("Engine running");
    } else {
      engineRpm = 0;
      engineRpmAvg = 0;
      for (uint8_t i = 0; i < RPM_AVG_WINDOW; i++) rpmSamples[i] = 0;
      rpmSampleIndex = 0;
      rpmSampleCount = 0;
      pendingEngineRpmPush = true;
      setErrorMessage("Engine stopped");
      remoteStarted = false;
      pendingStatePush = true;
    }
  }

  unsigned long now = millis();
  if ((engineRpm != lastPrintedEngineRpm || engineRunning != lastPrintedEngineRunning) &&
      (now - lastEngineDebugMs >= ENGINE_DEBUG_INTERVAL_MS)) {
    SerialMon.print("[ENGINE] rpm=");
    SerialMon.print(engineRpm);
    SerialMon.print(" avg=");
    SerialMon.print(engineRpmAvg);
    SerialMon.print(" running=");
    SerialMon.println(engineRunning ? "YES" : "NO");

    lastPrintedEngineRpm = engineRpm;
    lastPrintedEngineRunning = engineRunning;
    lastEngineDebugMs = now;
  }
}

bool sendCanHex(const char* slcanCmd) {
  if (slcanCmd == nullptr || strlen(slcanCmd) < 5) {
    SerialMon.println("[CAN] Invalid SLCAN string");
    return false;
  }

  twai_message_t msg = {};
  int dlcPos = 0;

  bool isExtended = (slcanCmd[0] == 'T' || slcanCmd[0] == 'R');
  bool isRTR      = (slcanCmd[0] == 'r' || slcanCmd[0] == 'R');

  if (isExtended) {
    char idStr[9] = {0};
    strncpy(idStr, slcanCmd + 1, 8);
    msg.identifier = strtoul(idStr, nullptr, 16) & 0x1FFFFFFF;
    msg.extd = 1;
    dlcPos = 9;
  } else {
    char idStr[4] = {0};
    strncpy(idStr, slcanCmd + 1, 3);
    msg.identifier = strtoul(idStr, nullptr, 16) & 0x7FF;
    msg.extd = 0;
    dlcPos = 4;
  }

  msg.rtr = isRTR ? 1 : 0;
  msg.data_length_code = slcanCmd[dlcPos] - '0';
  if (msg.data_length_code > 8) msg.data_length_code = 8;

  if (!isRTR) {
    int dataStart = dlcPos + 1;
    for (int i = 0; i < msg.data_length_code; i++) {
      char byteStr[3] = {0};
      strncpy(byteStr, slcanCmd + dataStart + (i * 2), 2);
      msg.data[i] = strtoul(byteStr, nullptr, 16);
    }
  }

  esp_err_t err = twai_transmit(&msg, pdMS_TO_TICKS(50));
  if (err == ESP_OK) {
    SerialMon.print("[CAN] Sent: ");
    SerialMon.println(slcanCmd);
    return true;
  }

  SerialMon.print("[CAN] TX failed, err=");
  SerialMon.println((int)err);
  return false;
}

void readCanBus() {
  twai_message_t msg;
  while (twai_receive(&msg, 0) == ESP_OK) {
    busIsAlive = true;
    decodeEngineInfo1(msg);

#if CAN_RX_LOGGING
    printCanMessage(msg);
#endif
  }
}

/* =========================================================
   Bus wake / heartbeat
   ========================================================= */
void busWakeup() {
  SerialMon.println("[BUS] Wake request");
  th8056SetWakeMode();
  delay(20);

  sendCanHex("t10000000000000000000\r");
  sendCanHex("t6218004002000000000\r");

  delay(50);
  th8056SetNormalMode();

  busIsAlive = true;
  lastHeartbeat = millis();
  delay(150);
}

void manageBusActivity() {
  unsigned long now = millis();

  if (isBusRequestedToWakeUp) {
    busWakeup();
    isBusRequestedToWakeUp = false;
  }

  readCanBus();

  if (busIsAlive && (now - lastHeartbeat >= HEARTBEAT_INTERVAL)) {
    lastHeartbeat = now;
    sendCanHex("t6218004002000000000\r");
  }

  if (busIsAlive && (now - lastAppActivity > BUS_IDLE_TIMEOUT)) {
    busIsAlive = false;
  }

  if (busIsAlive && pendingCommand != CMD_NONE) {
    switch (pendingCommand) {
      case CMD_UNLOCK_DOOR:
        SerialMon.println("[CMD] Unlock");
        sendCanHex("T1024E09730003FF\r");
        break;

      case CMD_LOCK_DOOR:
        SerialMon.println("[CMD] Lock");
        sendCanHex("T1024E09730001FF\r");
        break;

      case CMD_ALARM_ON:
        SerialMon.println("[CMD] Alarm ON");
        sendCanHex("T1024E09733000FF\r");
        break;

      case CMD_ALARM_OFF:
        SerialMon.println("[CMD] Alarm OFF");
        sendCanHex("T1024E09731000FF\r");
        break;

      case CMD_LIGHTS_ON:
        SerialMon.println("[CMD] Lights ON");
        sendCanHex("T1024E09730C00FF\r");
        break;

      case CMD_LIGHTS_OFF:
        SerialMon.println("[CMD] Lights OFF");
        sendCanHex("T1024E09730400FF\r");
        break;

      case CMD_REMOTE_START:
        if (engineRunning) {
          SerialMon.println("[CMD] Remote Start blocked: engine already running");
          setErrorMessage("Engine running - remote start blocked");
          remoteStarted = false;
          pendingStatePush = true;
        } else {
          SerialMon.println("[CMD] Remote Start ON");
          setErrorMessage("Remote start request sent");
          sendCanHex("T1024E09738001FF\r");
        }
        break;

      case CMD_REMOTE_START_OFF:
        SerialMon.println("[CMD] Remote Start OFF");
        setErrorMessage("Remote start cancel sent");
        sendCanHex("T1024E09734000FF\r");
        break;

      case CMD_GET_LOCATION:
        SerialMon.println("[CMD] Get Location");
        requestVehicleLocation = true;
        break;

      default:
        break;
    }
    pendingCommand = CMD_NONE;
  }
}

/* =========================================================
   Wi-Fi location payload
   ========================================================= */
void handleVehicleLocation() {
  SerialMon.println("[LOC] Scanning Wi-Fi");

  WiFi.mode(WIFI_STA);
  WiFi.disconnect(true, true);
  delay(200);

  int n = WiFi.scanNetworks();
  if (n <= 0) {
    SerialMon.println("[LOC] No Wi-Fi APs found");
    if (Blynk.connected()) Blynk.virtualWrite(V8, "{\"error\":\"no_wifi_found\"}");
    return;
  }

  struct WiFiAP {
    String bssid;
    int rssi;
    int channel;
  };

  WiFiAP aps[32];
  if (n > 32) n = 32;

  for (int i = 0; i < n; i++) {
    aps[i].bssid = WiFi.BSSIDstr(i);
    aps[i].rssi = WiFi.RSSI(i);
    aps[i].channel = WiFi.channel(i);
  }

  for (int i = 0; i < n - 1; i++) {
    for (int j = i + 1; j < n; j++) {
      if (aps[j].rssi > aps[i].rssi) {
        WiFiAP t = aps[i];
        aps[i] = aps[j];
        aps[j] = t;
      }
    }
  }

  DynamicJsonDocument doc(1024);
  JsonArray arr = doc.createNestedArray("wifiAccessPoints");

  int count = min(6, n);
  for (int i = 0; i < count; i++) {
    JsonObject o = arr.createNestedObject();
    o["macAddress"] = aps[i].bssid;
    o["signalStrength"] = aps[i].rssi;
    o["channel"] = aps[i].channel;
  }

  String jsonStr;
  serializeJson(doc, jsonStr);
  WiFi.scanDelete();

  SerialMon.println("[LOC] Payload:");
  SerialMon.println(jsonStr);

  if (Blynk.connected()) Blynk.virtualWrite(V8, jsonStr);
}

/* =========================================================
   Modem / LTE helpers
   ========================================================= */
void modemPowerDown() {
  SerialMon.println("\n=== Modem power down ===");
  ioexpWrite(IO_P3, false);
  ioexpWrite(IO_P1, false);
  delay(1000);
}

void modemPowerSequence() {
  SerialMon.println("\n=== Modem power sequence (I2C expander) ===");

  digitalWrite(LTE_RTS_PIN, LOW);

  ioexpWrite(IO_P3, false);
  ioexpWrite(IO_P1, false);
  delay(500);

  ioexpWrite(IO_P1, true);
  SerialMon.println("[MODEM] LTE power ON");
  delay(400);

  ioexpWrite(IO_P3, false);
  delay(400);

  ioexpWrite(IO_P3, true);
  SerialMon.println("[MODEM] LTE reset released");
  delay(4000);

  if (!waitForCTS(5000)) SerialMon.println("[MODEM] CTS stayed HIGH, continuing anyway");
  else SerialMon.println("[MODEM] CTS ready");
}

void restartModemUart() {
  MODEM_SERIAL.end();
  delay(300);
  MODEM_SERIAL.begin(115200, SERIAL_8N1, LTE_RX_PIN, LTE_TX_PIN);
  delay(800);
}

void modemHardRecover() {
  SerialMon.println("[RECOVERY] Initiating modem reboot");
  Blynk.disconnect();
  modemPowerDown();
  delay(1500);
  modemPowerSequence();
  restartModemUart();
}

void printBasicInfo() {
  SerialMon.print("Modem name: ");
  SerialMon.println(modem.getModemName());
  SerialMon.print("Modem info: ");
  SerialMon.println(modem.getModemInfo());
  SerialMon.print("Operator: ");
  SerialMon.println(modem.getOperator());
  SerialMon.print("Signal: ");
  SerialMon.println(modem.getSignalQuality());
  SerialMon.print("Local IP: ");
  SerialMon.println(modem.localIP());
}

bool modemRespondsToAT() {
  String r = modemSendATGetResp("AT", 1200, false);
  return respHasOK(r);
}

bool attachDataStandaloneOnce() {
  SerialMon.println("[LTE] Standalone attach attempt");

  modemSendATGetResp("AT+CFUN=1", 3000, false);

  char cmd[96];
  snprintf(cmd, sizeof(cmd), "AT+CGDCONT=1,\"IP\",\"%s\"", apn);
  modemSendATGetResp(cmd, 2000, false);

  modemSendATGetResp("AT+CGATT=1", 6000, false);
  String att = modemSendATGetResp("AT+CGATT?", 2000, false);
  if (att.indexOf("+CGATT: 1") < 0) {
    SerialMon.println("[LTE] CGATT still not 1");
    return false;
  }

  modemSendATGetResp("AT+CGACT=1,1", 6000, false);
  String ip = modemSendATGetResp("AT+CGPADDR=1", 2500, false);
  if (ip.indexOf("+CGPADDR: 1,\"") < 0) {
    SerialMon.println("[LTE] No PDP IP yet");
    return false;
  }

  SerialMon.println("[LTE] Standalone attach OK");
  return true;
}

bool attachDataStandaloneWithRetries(uint8_t tries = 3) {
  for (uint8_t i = 0; i < tries; i++) {
    SerialMon.printf("[LTE] Attach try %u/%u\n", i + 1, tries);
    if (attachDataStandaloneOnce()) return true;
    delay(1500);
  }
  return false;
}

bool pingStandalone() {
  SerialMon.println("[LTE] Running ping test...");
  String r = modemSendATGetResp("AT+PING=\"8.8.8.8\"", 9000, false);

  bool ok = (r.indexOf("+PING:") >= 0 && r.indexOf(",0,0") < 0) || respHasOK(r);
  if (ok) SerialMon.println("[LTE] Ping OK");
  else SerialMon.println("[LTE] Ping failed");
  return ok;
}

bool ensureLteReadyBeforeBlynk() {
  SerialMon.println("\n=== Ensure LTE ready before Blynk ===");

  if (!modemRespondsToAT()) {
    SerialMon.println("[LTE] No AT response");
    return false;
  }

  if (!modem.init()) {
    SerialMon.println("[LTE] modem.init() failed");
    return false;
  }

  if (!modem.waitForNetwork(45000L)) {
    SerialMon.println("[LTE] waitForNetwork failed");
  }

  if (modem.isGprsConnected()) {
    modem.gprsDisconnect();
    delay(1000);
  }

  if (!modem.gprsConnect(apn, gprsUser, gprsPass)) {
    SerialMon.println("[LTE] TinyGSM gprsConnect failed, trying standalone attach flow");
    if (!attachDataStandaloneWithRetries(3)) return false;
  }

  if (!modem.isGprsConnected()) {
    SerialMon.println("[LTE] TinyGSM still says GPRS not connected, retrying standalone attach");
    if (!attachDataStandaloneWithRetries(2)) return false;
  }

  if (!pingStandalone()) {
    SerialMon.println("[LTE] Ping not OK, LTE not ready for Blynk");
    return false;
  }

  lastSignalQuality = modem.getSignalQuality();
  printBasicInfo();
  return true;
}

bool connectBlynkOnlyIfPingOK() {
  if (!pingStandalone()) {
    SerialMon.println("[BLYNK] Not connecting, ping failed");
    return false;
  }

  SerialMon.println("\n=== Blynk connect ===");
  Blynk.config(modem, BLYNK_AUTH_TOKEN, "blynk.cloud", 80);

  if (!Blynk.connect(15000)) {
    SerialMon.println("[BLYNK] connect failed");
    return false;
  }

  SerialMon.println("[BLYNK] connected");
  forceFullBlynkPublish = true;
  pendingStatePush = true;
  pendingEnginePush = true;
  pendingEngineFlagPush = true;
  pendingEngineErrorPush = true;
  pendingEngineRpmPush = true;
  return true;
}

bool fullConnect() {
  if (!ensureLteReadyBeforeBlynk()) return false;
  if (!connectBlynkOnlyIfPingOK()) return false;
  return true;
}

bool recoverFromRIorLteLoss() {
  SerialMon.println("[RECOVERY] Disconnecting Blynk before LTE check");
  Blynk.disconnect();
  delay(500);

  if (pingStandalone()) {
    SerialMon.println("[RECOVERY] LTE still answers ping, reconnecting Blynk only");
    if (connectBlynkOnlyIfPingOK()) {
      lastRIActivityMs = millis();
      riLossAnnounced = false;
      networkFailCount = 0;
      return true;
    }
    networkFailCount++;
    return false;
  }

  SerialMon.println("[RECOVERY] Ping failed, rebooting modem");
  modemHardRecover();

  if (!ensureLteReadyBeforeBlynk()) {
    SerialMon.println("[RECOVERY] LTE not ready after modem reboot");
    networkFailCount++;
    return false;
  }

  if (!connectBlynkOnlyIfPingOK()) {
    SerialMon.println("[RECOVERY] Blynk reconnect failed after LTE recovery");
    networkFailCount++;
    return false;
  }

  lastRIActivityMs = millis();
  riLossAnnounced = false;
  networkFailCount = 0;
  SerialMon.println("[RECOVERY] Modem + LTE + Blynk restored");
  return true;
}

/* =========================================================
   RI monitoring
   ========================================================= */
void processRI() {
  if (millis() - lastRingPoll >= 250) {
    bool ringNow = readLteRing();
    if (ringNow != lastRingState) {
      lastRingState = ringNow;
      lastRIActivityMs = millis();
      riLossAnnounced = false;
      SerialMon.printf("[RI] %s\n", ringNow ? "HIGH" : "LOW");
    }
    lastRingPoll = millis();
  }
}

bool riLooksDeadTooLong() {
  return (millis() - lastRIActivityMs) > RI_ACTIVITY_TIMEOUT_MS;
}

/* =========================================================
   Serial menu
   ========================================================= */
String cleanInput(const String &src) {
  String out;
  for (size_t i = 0; i < src.length(); i++) {
    char ch = src[i];
    if (ch >= 32 && ch <= 126) out += ch;
  }
  out.trim();
  return out;
}

void printMenu() {
  SerialMon.println();
  SerialMon.println("Commands:");
  SerialMon.println("menu       - show menu");
  SerialMon.println("probe      - modem info");
  SerialMon.println("signal     - CSQ/CESQ/network");
  SerialMon.println("attach     - standalone LTE attach retries");
  SerialMon.println("ping       - standalone ping test");
  SerialMon.println("blynk      - connect Blynk only if ping ok");
  SerialMon.println("reconnect  - full LTE/Blynk recovery");
  SerialMon.println("status     - compact status");
  SerialMon.println("at         - plain AT");
  SerialMon.println("Any other line sends raw AT command");
  SerialMon.println();
}

void printModemProbe() {
  SerialMon.println("\n=== Probe modem ===");
  modemSendATGetResp("AT", 1200);
  modemSendATGetResp("ATI", 2000);
  modemSendATGetResp("AT+CGMR", 1500);
  modemSendATGetResp("AT+CPIN?", 1200);
  modemSendATGetResp("AT+CEREG?", 1200);
  modemSendATGetResp("AT+CSQ", 1200);
  modemSendATGetResp("AT+CESQ", 1200);
  modemSendATGetResp("AT+SQNMONI=0", 2500);
  SerialMon.println("===================");
}

void printStatus() {
  SerialMon.println("\n=== STATUS ===");
  SerialMon.printf("RSSI=%d\n", lastSignalQuality);
  SerialMon.printf("NET=%d GPRS=%d BLYNK=%d FAILS=%u\n",
                   modem.isNetworkConnected() ? 1 : 0,
                   modem.isGprsConnected() ? 1 : 0,
                   Blynk.connected() ? 1 : 0,
                   networkFailCount);
  SerialMon.printf("RI age ms=%lu\n", millis() - lastRIActivityMs);
  SerialMon.printf("ENGINE RPM=%d AVG=%d RUNNING=%d RAW=0x%04X MON=%d\n",
                   engineRpm, engineRpmAvg, engineRunning ? 1 : 0,
                   engineRpmRaw, engineMonitoringActive() ? 1 : 0);
  SerialMon.print("ENGINE MSG=");
  SerialMon.println(errorMessage);
  SerialMon.println("==============");
}

void handleSerialMenu() {
  while (SerialMon.available()) {
    char c = (char)SerialMon.read();

    if (c == '\r' || c == '\n') {
      if (serialInput.length() > 0) {
        String cmd = cleanInput(serialInput);
        serialInput = "";

        if (cmd.equalsIgnoreCase("menu") || cmd.equalsIgnoreCase("help")) {
          printMenu();
        } else if (cmd.equalsIgnoreCase("probe")) {
          printModemProbe();
        } else if (cmd.equalsIgnoreCase("signal")) {
          modemSendATGetResp("AT+CSQ", 1200);
          modemSendATGetResp("AT+CESQ", 1200);
          modemSendATGetResp("AT+SQNMONI=0", 2500);
        } else if (cmd.equalsIgnoreCase("attach")) {
          attachDataStandaloneWithRetries(3);
        } else if (cmd.equalsIgnoreCase("ping")) {
          pingStandalone();
        } else if (cmd.equalsIgnoreCase("blynk")) {
          connectBlynkOnlyIfPingOK();
        } else if (cmd.equalsIgnoreCase("reconnect")) {
          recoverFromRIorLteLoss();
        } else if (cmd.equalsIgnoreCase("status")) {
          printStatus();
        } else if (cmd.equalsIgnoreCase("at")) {
          modemSendATGetResp("AT", 1200);
        } else {
          modemSendATGetResp(cmd.c_str(), 2500);
        }
      }
    } else if (c >= 32 && c <= 126) {
      if (serialInput.length() < 120) serialInput += c;
    }
  }
}

/* =========================================================
   Connection maintenance
   ========================================================= */
void maintainConnections() {
  if (millis() - lastNetCheck < NET_CHECK_INTERVAL_MS) return;
  lastNetCheck = millis();

  bool netOk = modem.isNetworkConnected();
  bool gprsOk = modem.isGprsConnected();
  bool blynkOk = Blynk.connected();

  int sig = modem.getSignalQuality();
  if (sig >= 0) lastSignalQuality = sig;

#if NET_DEBUG_LOGGING
  SerialMon.printf("[NET] RSSI=%d NET=%d GPRS=%d BLYNK=%d FAILS=%u\n",
                   lastSignalQuality,
                   netOk ? 1 : 0,
                   gprsOk ? 1 : 0,
                   blynkOk ? 1 : 0,
                   networkFailCount);
#endif

  if (riLooksDeadTooLong()) {
    if (!riLossAnnounced) {
      SerialMon.println("[NET] No RI activity for 70s - checking LTE path");
      riLossAnnounced = true;
    }
    recoverFromRIorLteLoss();
    return;
  }

  if (!netOk || !gprsOk) {
    SerialMon.println("[RECOVERY] LTE path unhealthy");
    recoverFromRIorLteLoss();
    return;
  }

  if (!blynkOk && netOk && gprsOk) {
    SerialMon.println("[RECOVERY] LTE OK, Blynk down -> reconnecting Blynk");
    if (connectBlynkOnlyIfPingOK()) {
      networkFailCount = 0;
      return;
    }
    networkFailCount++;
    return;
  }

  networkFailCount = 0;
}

/* =========================================================
   Blynk status sender
   ========================================================= */
void periodicBlynkPublisher() {
  if (!Blynk.connected()) return;

  if (forceFullBlynkPublish) {
    pushSlowStatus(true);
    pushStateNow(true);
    forceFullBlynkPublish = false;
    return;
  }

  pushSlowStatus(false);

  if (pendingStatePush || pendingEnginePush) {
    pushStateNow(false);
  }
}

/* =========================================================
   Blynk callbacks
   ========================================================= */
BLYNK_CONNECTED() {
  SerialMon.println("[BLYNK] Connected callback");
  Blynk.syncVirtual(V0, V1, V2, V3, V4, V5, V6, V7);
  forceFullBlynkPublish = true;
  pendingStatePush = true;
  pendingEnginePush = true;
  pendingEngineFlagPush = true;
  pendingEngineErrorPush = true;
  pendingEngineRpmPush = true;
}

BLYNK_WRITE(V0) {
  if (param.asInt() && !doorUnlocked) {
    doorUnlocked = true;
    pendingStatePush = true;
    lastAppActivity = millis();
    if (!busIsAlive) isBusRequestedToWakeUp = true;
    pendingCommand = CMD_UNLOCK_DOOR;
  }
}

BLYNK_WRITE(V1) {
  if (param.asInt() && doorUnlocked) {
    doorUnlocked = false;
    pendingStatePush = true;
    lastAppActivity = millis();
    if (!busIsAlive) isBusRequestedToWakeUp = true;
    pendingCommand = CMD_LOCK_DOOR;
  }
}

BLYNK_WRITE(V2) {
  if (param.asInt() && !alarmOn) {
    alarmOn = true;
    pendingStatePush = true;
    lastAppActivity = millis();
    if (!busIsAlive) isBusRequestedToWakeUp = true;
    pendingCommand = CMD_ALARM_ON;
  }
}

BLYNK_WRITE(V3) {
  if (param.asInt() && alarmOn) {
    alarmOn = false;
    pendingStatePush = true;
    lastAppActivity = millis();
    if (!busIsAlive) isBusRequestedToWakeUp = true;
    pendingCommand = CMD_ALARM_OFF;
  }
}

BLYNK_WRITE(V4) {
  if (param.asInt() && !lightsFlashing) {
    lightsFlashing = true;
    pendingStatePush = true;
    lastAppActivity = millis();
    if (!busIsAlive) isBusRequestedToWakeUp = true;
    pendingCommand = CMD_LIGHTS_ON;
  }
}

BLYNK_WRITE(V5) {
  if (param.asInt() && lightsFlashing) {
    lightsFlashing = false;
    pendingStatePush = true;
    lastAppActivity = millis();
    if (!busIsAlive) isBusRequestedToWakeUp = true;
    pendingCommand = CMD_LIGHTS_OFF;
  }
}

BLYNK_WRITE(V6) {
  if (param.asInt()) {
    lastAppActivity = millis();
    if (!busIsAlive) isBusRequestedToWakeUp = true;

    startEngineMonitorWindow();

    if (engineRunning) {
      SerialMon.println("[CMD] Remote Start requested but engine already running");
      setErrorMessage("Engine running - remote start blocked");
      remoteStarted = false;
      pendingStatePush = true;
      pendingCommand = CMD_NONE;
      return;
    }

    if (!remoteStarted) {
      remoteStarted = true;
      pendingStatePush = true;
      setErrorMessage("Remote start requested");
      pendingCommand = CMD_REMOTE_START;
    } else {
      remoteStarted = false;
      pendingStatePush = true;
      setErrorMessage("Remote start cancel requested");
      pendingCommand = CMD_REMOTE_START_OFF;
    }
  }
}

BLYNK_WRITE(V7) {
  if (param.asInt()) {
    lastAppActivity = millis();
    if (!busIsAlive) isBusRequestedToWakeUp = true;
    pendingCommand = CMD_GET_LOCATION;
  }
}

/* =========================================================
   Setup
   ========================================================= */
void setup() {
  SerialMon.begin(115200);
  delay(1000);
  SerialMon.println();
  SerialMon.println("Booting SGW F1 starter kit sketch...");

  bootTime = millis();

  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);

  writeReg(REG_CONFIG, 0xE0);
  ioexpOut = 0;
  writeReg(REG_OUTPUT, ioexpOut);

  pinMode((int)TH8056_MODE0_PIN, OUTPUT);
  pinMode((int)TH8056_MODE1_PIN, OUTPUT);
  th8056SetNormalMode();

  pinMode(LTE_RTS_PIN, OUTPUT);
  pinMode(LTE_CTS_PIN, INPUT);
  digitalWrite(LTE_RTS_PIN, LOW);

  MODEM_SERIAL.begin(115200, SERIAL_8N1, LTE_RX_PIN, LTE_TX_PIN);
  delay(300);

  twai_general_config_t g_config = TWAI_GENERAL_CONFIG_DEFAULT(CAN_TX_PIN, CAN_RX_PIN, TWAI_MODE_NORMAL);
  twai_filter_config_t  f_config = TWAI_FILTER_CONFIG_ACCEPT_ALL();

  esp_err_t err;
  err = twai_driver_install(&g_config, &TWAI_TIMING_33K3, &f_config);
  SerialMon.print("[TWAI] driver_install = ");
  SerialMon.println((int)err);
  if (err != ESP_OK) {
    SerialMon.println("[TWAI] driver install failed");
    while (true) delay(1000);
  }

  err = twai_start();
  SerialMon.print("[TWAI] start = ");
  SerialMon.println((int)err);
  if (err != ESP_OK) {
    SerialMon.println("[TWAI] start failed");
    while (true) delay(1000);
  }

  SerialMon.println("[TWAI] ready");

  setErrorMessage("Boot complete");

  modemPowerSequence();
  restartModemUart();

  if (!fullConnect()) {
    SerialMon.println("[BOOT] Initial LTE/Blynk connect failed");
    setErrorMessage("LTE/Blynk connect failed");
  } else {
    SerialMon.println("[BOOT] LTE/Blynk connected");
    setErrorMessage("LTE/Blynk connected");
  }

  lastRingState = readLteRing();
  lastRIActivityMs = millis();

  timer.setInterval(STATUS_INTERVAL_MS, periodicBlynkPublisher);

  printMenu();
}

/* =========================================================
   Loop
   ========================================================= */
void loop() {
  processRI();

  Blynk.run();
  timer.run();
  modem.maintain();

  handleSerialMenu();
  manageBusActivity();
  maintainConnections();

  if (requestVehicleLocation) {
    requestVehicleLocation = false;
    handleVehicleLocation();
  }

  delay(2);
}